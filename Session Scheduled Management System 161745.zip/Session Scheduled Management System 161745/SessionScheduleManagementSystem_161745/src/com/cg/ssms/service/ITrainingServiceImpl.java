package com.cg.ssms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ssms.dao.ITrainingDAO;
import com.cg.ssms.dto.Session;
//Below line declared the Service layer named as "service"
@Service("service")
@Transactional
public class ITrainingServiceImpl implements ITrainingService {
	@Autowired
	ITrainingDAO trainingdao;


	@Override
	//The below method will be redirect to DAO layer 
	public List<Session> viewScheduledSessions() {
		// TODO Auto-generated method stub
		return trainingdao.viewScheduledSessions();
	}

}
