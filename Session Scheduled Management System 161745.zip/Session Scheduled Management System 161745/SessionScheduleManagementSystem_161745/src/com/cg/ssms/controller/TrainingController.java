package com.cg.ssms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ssms.dto.Session;
import com.cg.ssms.service.ITrainingService;
//Training Controller Class
@Controller
public class TrainingController {

	@Autowired
	ITrainingService service;
	//Below method will display the data from the database to the ScheduledSessions.jsp page
	@RequestMapping(value = "showall", method = RequestMethod.GET)
	public ModelAndView getAllDetails() {
		List<Session> sesData = service.viewScheduledSessions();
		return new ModelAndView("ScheduledSessions", "data", sesData);
	}
	//Below method will return the session name to the Success.jsp page
	@RequestMapping(value = "Success", method = RequestMethod.GET)
	public ModelAndView datadisplay(@RequestParam("sesname") String sname) {
		return new ModelAndView("Success", "sname", sname);
	}
}
