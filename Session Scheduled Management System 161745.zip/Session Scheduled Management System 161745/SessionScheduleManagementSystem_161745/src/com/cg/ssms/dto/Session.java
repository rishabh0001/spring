package com.cg.ssms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ScheduledSessions")
public class Session {
@Id
@Column(name="id")
int sessionId;
@Column(name="name")
String sessionName;
@Column(name="duration")
int sessionDuration;
@Column(name="faculty")
String sessionFacultyName;
@Column(name="mode1")
String sessionMode;
public Session() {

}
public Session(String sessionName, int sessionDuration,
		String sessionFacultyName, String sessionMode) {
	super();
	this.sessionName = sessionName;
	this.sessionDuration = sessionDuration;
	this.sessionFacultyName = sessionFacultyName;
	this.sessionMode = sessionMode;
}
public String getSessionName() {
	return sessionName;
}
public void setSessionName(String sessionName) {
	this.sessionName = sessionName;
}
public int getSessionDuration() {
	return sessionDuration;
}
public void setSessionDuration(int sessionDuration) {
	this.sessionDuration = sessionDuration;
}
public String getSessionFacultyName() {
	return sessionFacultyName;
}
public void setSessionFacultyName(String sessionFacultyName) {
	this.sessionFacultyName = sessionFacultyName;
}
public String getSessionMode() {
	return sessionMode;
}
public void setSessionMode(String sessionMode) {
	this.sessionMode = sessionMode;
}
@Override
public String toString() {
	return "Session [sessionName=" + sessionName + ", sessionDuration="
			+ sessionDuration + ", sessionFacultyName=" + sessionFacultyName
			+ ", sessionMode=" + sessionMode + "]";
}
}
