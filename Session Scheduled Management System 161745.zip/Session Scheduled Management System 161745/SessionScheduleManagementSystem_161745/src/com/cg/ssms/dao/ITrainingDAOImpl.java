package com.cg.ssms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.ssms.dto.Session;
//Below line declared the DAO layer named as "trainingdao"
@Repository("trainingdao")
public class ITrainingDAOImpl implements ITrainingDAO {
	@PersistenceContext
	EntityManager em;
	@Override
	//The below method will return the data of database which is declared in the Session class 
	public List<Session> viewScheduledSessions() {
		Query queryGet=em.createQuery("FROM Session");
		@SuppressWarnings("unchecked")
		List<Session> myList=queryGet.getResultList();
		// TODO Auto-generated method stub
		return myList;
	}

}
